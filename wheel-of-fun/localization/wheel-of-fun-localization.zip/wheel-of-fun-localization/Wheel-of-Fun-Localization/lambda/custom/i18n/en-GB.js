module.exports = {
    translation : {
        WELCOME_MESSAGE : 'I shall spin the British Wheel of Fun for you.',
        STOP_MESSAGE : "Toodle-oo!"
    }
};