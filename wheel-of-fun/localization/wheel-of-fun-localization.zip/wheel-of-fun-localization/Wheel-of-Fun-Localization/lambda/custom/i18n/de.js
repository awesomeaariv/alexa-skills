module.exports = {
    translation : {
        WELCOME_MESSAGE : 'Ich werde das Rad des Spaßes für dich drehen.'
    } 
};