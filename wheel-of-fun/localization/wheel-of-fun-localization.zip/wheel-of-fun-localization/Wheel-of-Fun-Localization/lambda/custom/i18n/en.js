module.exports = {
    translation : {
        SKILL_NAME : 'Wheel of Fun',
        HELP_MESSAGE : 'You can say spin the wheel of fun, or, you can say exit. Would you like to spin once more?',
        HELP_REPROMPT : 'What can I help you with?',
        STOP_MESSAGE : 'Goodbye!',
        FALLBACK_MESSAGE : 'Sorry, I did not catch that. Would you like to spin the wheel?',
        FALLBACK_REPROMPT : 'You can say yes to have more fun or no to stop.',
        WELCOME_MESSAGE : 'I will spin the Wheel of Fun for you. ',
        YES_REPROMPT : 'Would you like to spin again?',
        ERROR_MESSAGE : 'Sorry, an error occurred.',
        JOKES_MESSAGE : ["Too chicken to spin? No problem. Here's a joke: "],
        FART_MESSAGE : ["Here you go!"],

        BEGINNING_MUSIC : '<audio src="https://s3.amazonaws.com/xxxx/wheel-of-fun-welcome-music.mp3"/>',
        ENDING_MUSIC : '<audio src="https://s3.amazonaws.com/xxxx/wheel-of-fun-ending-music.mp3"/>',

        typesOfContentFart : 'uh ',
        typesOfContentPoem : 'a poem. ',
        typesOfContentAdvice : 'some advice. ',
        typesOfContentFact : 'a fact. ',
        typesOfContentJoke : 'a joke. ',
        typesOfContentCompliment : 'a compliment. ',
        typesOfContentFortune : 'a fortune. ',

        advice : [ // 37
            "Never trust a dog to watch your food.",
            "When your dad is mad and asks you 'Do I look stupid?', don't answer.",
            "Never tell your mom her diet's not working."
        ],

        facts : [ // 63
            "A crocodile cannot stick its tongue out.",
            "An ostrich's eye is bigger than its brain.",
            "Tigers have striped skin, not just striped fur."
        ],

        jokes : [ // 50
            "Why did the cookie go to the hospital? Because he felt crummy!",
            "What did the policeman say to his belly button? You're under a vest!",
            "What do you call a fake noodle? An impasta!"
        ],

        compliments : [ // 35
            "You look great today.",
            "You're a smart cookie.",
            "I like your style."
        ],

        poems : [ // 13
            "I've hunted near, I've hunted far. I even looked inside my car. I've lost my glasses, I'm in need, to have them now so I can read.",
            "I once had a kitty who had stripes in her fur. I could pet her and brush her, and boy could she purr.",
            "I made myself a snowball, as perfect as could be. I thought I'd keep it as a pet and let it sleep with me."
        ],

        fortunes : [
            "You will accomplish great things.",
            "You will have many friends.",
            "You will enjoy a relaxing vacation."
        ],
        
        fartSounds : [ // 11
            '<audio src = "https://s3.amazonaws.com/xxxxx/common-fart-2.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/common-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/fart-noises.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/king-farthur.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/motorcycle-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/trumpet-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/wet-fart-squish.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/bean-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/rigid-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/wont-start-fart.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/squeeze-yer-knees.mp3"/>'
        ],

        fartMessages : [
            "Yuck, was that you?",
            "Hey, who cut the cheese?"
        ],

        wheelSounds : [
            '<audio src = "https://s3.amazonaws.com/xxxx/wheel-spin-1.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxx/wheel-spin-2.mp3"/>'
        ],

        morePrompts : [
            "Would you like to spin the wheel again?",
            "Would you like to spin the wheel once more?"
        ],

        beginPrompts : [ // 10
            `The Wheel of Fun has decided to give you `,
            `The wheel has given you `
        ],

        yesSpeechcons : [
            '<say-as interpret-as = "interjection">as you wish</say-as>',
            '<say-as interpret-as = "interjection">okey dokey</say-as>'
        ],

        noSpeechcons : [
            '<say-as interpret-as = "interjection">bummer</say-as>',
            '<say-as interpret-as = "interjection">darn</say-as>'
        ],

        jokeAndAdviceSfx : [ // 4
            '<audio src = "https://s3.amazonaws.com/xxxxx/toing-jelly-effect.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/jokesoundeffect.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/failsoundeffect.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/whawha.mp3"/>'
        ],

        complimentSfx : [ // 2
            '<audio src = "https://s3.amazonaws.com/xxxxx/compliment-sfx/cheering-one.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/compliment-sfx/cheering-two.mp3"/>'
        ],

        poemSfx : [ // 4
            '<audio src = "https://s3.amazonaws.com/xxxxx/poems-sfx/cheering-two.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/poems-sfx/cheering-one.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/poems-sfx/light-applause.mp3"/>',
            '<audio src = "https://s3.amazonaws.com/xxxxx/poems-sfx/standing-ovation.mp3"/>'
        ],

        factSfx : [ // 1
            '<audio src = "https://s3.amazonaws.com/xxxxx/fact-sfx/ding-fact.mp3"/>'
        ],

        fortuneSfx : [
            '<audio src = "https://s3.amazonaws.com/xxxxx/fortune-sfx/fortune.mp3"/>'
        ]
    } 
};