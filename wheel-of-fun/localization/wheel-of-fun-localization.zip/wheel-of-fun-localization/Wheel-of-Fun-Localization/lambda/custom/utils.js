module.exports = {
    
    addBreak : function (breakSeconds) {
        return `<break time="${breakSeconds}s"/>`;
    },

    saveLastResponse : function (handlerInput, speechOutput) {
        const attributes = handlerInput.attributesManager.getSessionAttributes();
        attributes.lastResponse = "Okay! " + speechOutput + " Would you like to spin?";

        //SAVE ATTRIBUTES
        handlerInput.attributesManager.setSessionAttributes(attributes);
    }
};