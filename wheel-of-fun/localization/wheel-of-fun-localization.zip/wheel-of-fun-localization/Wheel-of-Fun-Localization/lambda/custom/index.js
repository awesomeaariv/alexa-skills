/* eslint-disable  func-names */
/* eslint-disable  no-console */

const Alexa = require('ask-sdk-core');

//const dashbot = require('dashbot')('OniR4Ux8qQFehqc4JVraZ0J5ieJ2qDsDe0fA1wVS').alexa;

// These two modules are needed in order to make your skill multi-lingual.
const i18n = require('i18next'); 
const sprintf = require('i18next-sprintf-postprocessor'); 

const utils = require('./utils');

// Include the content file for each locale
const languageStrings = {
    'en' : require('./i18n/en'),
    'en-GB' : require('./i18n/en-GB'),
    'de' : require('./i18n/de'),
};

const GetItemIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest'
      || (request.type === 'IntentRequest'
        && request.intent.name === 'GetItemIntent');
  },
  handle(handlerInput) {
    // You must also add this first line WHEREVER you are using requestAttributes.t();
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
    getContent(handlerInput);
    //        In order to use the localizationInterceptor, you must write "requestAttributes.t('YOUR_MESSAGE')"
    //                    Also note that if you have an array, .t() will choose a random element
    var speechOutput = requestAttributes.t('WELCOME_MESSAGE') + getContent.speechOutput;
    
    utils.saveLastResponse(handlerInput, getContent.repeatOutput);

    return handlerInput.responseBuilder
      .speak(requestAttributes.t('BEGINNING_MUSIC') + speechOutput)
      .reprompt(requestAttributes.t('YES_REPROMPT'))
      .withSimpleCard(requestAttributes.t('SKILL_NAME'), getContent.cardOutput)
      .getResponse();
  },
};

const YesIntentHandler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;

        return (request.type === 'IntentRequest'
            && request.intent.name === 'AMAZON.YesIntent');
      },
      handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

        var speechOutput = getYesSpeechcon(handlerInput) + '. ' + utils.addBreak(1) + getContent(handlerInput);

        utils.saveLastResponse(handlerInput, getContent.repeatOutput);

    return handlerInput.responseBuilder
      .speak(speechOutput)
      .reprompt(requestAttributes.t('YES_REPROMPT'))
      .withSimpleCard(requestAttributes.t('SKILL_NAME'), getContent.cardOutput)
      .getResponse();
      },
};

const NoIntentHandler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;

        return (request.type === 'IntentRequest'
            && request.intent.name === 'AMAZON.NoIntent');
      },
      handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
        var speechOutput = getNoSpeechcon(handlerInput) + '. ' + utils.addBreak(1) + requestAttributes.t('STOP_MESSAGE');
        
        return handlerInput.responseBuilder
        .speak(requestAttributes.t('ENDING_MUSIC') + speechOutput)
        .getResponse();
      },
};
const GetJokeIntentHandler =  {
  canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return (request.type === 'IntentRequest'
          && request.intent.name === 'GetJokeIntent');
    },
    handle(handlerInput) {
      const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
      var speechOutput = requestAttributes.t('JOKES_MESSAGE') + utils.addBreak(1) + getJoke(handlerInput) + utils.addBreak(0.5) + getJokeAndAdviceSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
      utils.saveLastResponse(handlerInput, getJoke.repeatOutput);

      return handlerInput.responseBuilder
      .speak(speechOutput)
      .reprompt(requestAttributes.t('YES_REPROMPT'))
      .withSimpleCard(requestAttributes.t('SKILL_NAME'), getJoke.cardContent)
      .getResponse();
    },
};

const GetFartIntentHandler =  {
  canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return (request.type === 'IntentRequest'
          && request.intent.name === 'GetFartIntent');
    },
    handle(handlerInput) {
      const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
      var speechOutput = requestAttributes.t('FART_MESSAGE') + utils.addBreak(1) + getFartSound(handlerInput) + utils.addBreak(0.5) + getFartMessage(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
      var repeatOutput = requestAttributes.t('FART_MESSAGE') + utils.addBreak(1) + getFartSound.repeatOutput + utils.addBreak(0.5) + getFartMessage.repeatOutput + utils.addBreak(0.5);
      utils.saveLastResponse(handlerInput, repeatOutput);

      return handlerInput.responseBuilder
      .speak(speechOutput)
      .reprompt(requestAttributes.t('YES_REPROMPT'))
      .withSimpleCard(requestAttributes.t('SKILL_NAME'), getFartMessage.cardContent)
      .getResponse();
    },
};

const HelpHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

    var speechOutput = requestAttributes.t('HELP_MESSAGE');
    utils.saveLastResponse(handlerInput, speechOutput);

    return handlerInput.responseBuilder
      .speak(speechOutput)
      .reprompt(requestAttributes.t('HELP_REPROMPT'))
      .getResponse();
  },
};

const FallbackHandler = {
    canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
        && request.intent.name === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
      const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

      var speechOutput = requestAttributes.t('FALLBACK_MESSAGE');
      utils.saveLastResponse(handlerInput, speechOutput);

      return handlerInput.responseBuilder
        .speak(speechOutput)
        .reprompt(requestAttributes.t('FALLBACK_REPROMPT'))
        .getResponse();
    },
  };

const ExitHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && (request.intent.name === 'AMAZON.CancelIntent'
        || request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

    return handlerInput.responseBuilder
      .speak(requestAttributes.t('ENDING_MUSIC') + getNoSpeechcon(handlerInput) + '. ' + utils.addBreak(1) + requestAttributes.t('STOP_MESSAGE'))
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);
    if(null!=handlerInput.requestEnvelope.request.error) {
      console.log(JSON.stringify(handlerInput.requestEnvelope.request.error));
    }
    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
    
    console.log(`Error handled: ${error.message}`);
    if(null!=handlerInput.requestEnvelope.request.error) {
      console.log(JSON.stringify(handlerInput.requestEnvelope.request.error));
    }
    return handlerInput.responseBuilder
      .speak(requestAttributes.t('ERROR_MESSAGE'))
      .reprompt(requestAttributes.t('ERROR_MESSAGE'))
      .getResponse();
  },
};

const RepeatHandler = {
    canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;
      return request.type === 'IntentRequest'
        && request.intent.name === 'AMAZON.RepeatIntent';
    },
    handle(handlerInput) {
      const attributes = handlerInput.attributesManager.getSessionAttributes();

      return handlerInput.responseBuilder
        .speak(attributes.lastResponse)
        .reprompt('Are you still there?')
        .getResponse();
    },
  };

// Custom functions

function getContent(handlerInput) {
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();
    
    var typesOfContent = [requestAttributes.t('typesOfContentAdvice'), requestAttributes.t('typesOfContentFact'), requestAttributes.t('typesOfContentJoke'), requestAttributes.t('typesOfContentCompliment'), requestAttributes.t('typesOfContentFart'), requestAttributes.t('typesOfContentPoem'), requestAttributes.t('typesOfContentFortune')];
    var randomContent = Math.floor(Math.random() * typesOfContent.length);
    var randomBeginPrompt = requestAttributes.t('beginPrompts');
    getContent.speechOutput = getWheelSound(handlerInput) + randomBeginPrompt + typesOfContent[randomContent];
    var cardContent = "";
    getContent.repeatOutput = '';
    
    switch (randomContent) {
      case 0 : //Advice
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getAdvice(handlerInput) + utils.addBreak(0.5) + getJokeAndAdviceSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getAdvice.cardContent;
        getContent.repeatOutput = getAdvice.cardContent;
        break;
      case 1 : //Fact
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getFact(handlerInput) + utils.addBreak(0.5) + getFactsSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getFact.cardContent;
        getContent.repeatOutput = getFact.cardContent;
        break;
      case 2 : //Joke
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getJoke(handlerInput) + utils.addBreak(0.5) + getJokeAndAdviceSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getJoke.cardContent;
        getContent.repeatOutput = getJoke.cardContent;
        break;
      case 3 ://Compliment
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getCompliment(handlerInput) + utils.addBreak(0.5) + getComplimentsSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getCompliment.cardContent;
        getContent.repeatOutput = getCompliment.cardContent;
        break;
      case 4 : //Fart
        getContent.speechOutput = getContent.speechOutput + getFartSound(handlerInput) + utils.addBreak(0.5) + getFartMessage(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getFartMessage.cardContent;
        getContent.repeatOutput = getFartSound(handlerInput) + getFartMessage.cardContent;
        break;
      case 5 : //Poem
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getPoem(handlerInput) + utils.addBreak(0.5) + getPoemsSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getPoem.cardContent;
        getContent.repeatOutput = getPoem.cardContent;
        break;
      case 6 : //Fortune
        getContent.speechOutput = getContent.speechOutput + utils.addBreak(2) + getFortune(handlerInput) + utils.addBreak(0.5) + getFortuneSfx(handlerInput) + utils.addBreak(1) + ' ' + getMorePrompt(handlerInput);
        cardContent = getFortune.cardContent;
        getContent.repeatOutput = getFortune.cardContent;
        break;
      default : 
        console.log("Sux 2BU!!!");
    }

    getContent.cardOutput = cardContent;
    return getContent.speechOutput;
}

// Gets actual content

function getAdvice(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomAdvice = requestAttributes.t('advice');
  getAdvice.cardContent = randomAdvice;
  return randomAdvice;
}

function getJoke(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomJoke = requestAttributes.t('jokes');
  getJoke.cardContent = randomJoke;
  getJoke.repeatOutput = randomJoke + utils.addBreak(0.5) + getJokeAndAdviceSfx(handlerInput);
  return randomJoke;
}

function getFact(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomFact = requestAttributes.t('facts');
  getFact.cardContent = randomFact;
  return randomFact;
}

function getCompliment(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomCompliment = requestAttributes.t('compliments');
  getCompliment.cardContent = randomCompliment;
  return randomCompliment;
}

function getPoem(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomPoem = requestAttributes.t('poems');
  getPoem.cardContent = randomPoem;
  return randomPoem;
}

function getFortune(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomFortune = requestAttributes.t('fortunes');
  getFortune.cardContent = randomFortune;
  return randomFortune;
}

function getFartSound(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomFartSound = requestAttributes.t('fartSounds');
  getFartSound.cardContent = randomFartSound;
  getFartSound.repeatOutput = randomFartSound;
  return randomFartSound;
}

function getFartMessage(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomFartMessage = requestAttributes.t('fartMessages');
  getFartMessage.cardContent = randomFartMessage;
  getFartMessage.repeatOutput = randomFartMessage;
  return randomFartMessage;
}

// Gets sound effects

function getJokeAndAdviceSfx(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomSfx = requestAttributes.t('jokeAndAdviceSfx');
  return randomSfx;
}

function getComplimentsSfx(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomSfx = requestAttributes.t('complimentSfx');
  return randomSfx;
}

function getPoemsSfx(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomSfx = requestAttributes.t('poemSfx');
  return randomSfx;
}

function getFortuneSfx(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomSfx = requestAttributes.t('fortuneSfx');
  return randomSfx;
}

function getFactsSfx(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomSfx = requestAttributes.t('factSfx');
  return randomSfx;
}

// Miscellaneous

function getMorePrompt(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomMorePrompt = requestAttributes.t('morePrompts');
  return randomMorePrompt;
}

function getYesSpeechcon(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomYesSpeechcon = requestAttributes.t('yesSpeechcons');
  return randomYesSpeechcon;
}

function getNoSpeechcon(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomNoSpeechcon = requestAttributes.t('noSpeechcons');
  return randomNoSpeechcon;
}

function getWheelSound(handlerInput) {
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomWheelSound = requestAttributes.t('wheelSounds');
  return randomWheelSound;
}

// Add the LocalizationInterceptor code
// The LocalizationInterceptor will parse the incoming request and choose the correct language strings based on the user’s locale.

const LocalizationInterceptor = {
  process(handlerInput) {
      const localizationClient = i18n.use(sprintf).init({
          lng: handlerInput.requestEnvelope.request.locale,
          fallbackLng: 'en', // fallback to EN if locale doesn't exist
          resources: languageStrings
      });

      localizationClient.localize = function () {
          const args = arguments;
          let values = [];

          for (var i = 1; i < args.length; i++) {
              values.push(args[i]);
          }
          const value = i18n.t(args[0], {
              returnObjects: true,
              postProcess: 'sprintf',
              sprintf: values
          });

          if (Array.isArray(value)) {
              return value[Math.floor(Math.random() * value.length)];
          } else {
              return value;
          }
      };

      const attributes = handlerInput.attributesManager.getRequestAttributes();
      attributes.t = function (...args) {
          return localizationClient.localize(...args);
      };
  },
};

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    GetItemIntentHandler,
    HelpHandler,
    ExitHandler,
    SessionEndedRequestHandler,
    YesIntentHandler,
    NoIntentHandler,
    FallbackHandler,
    RepeatHandler,
    GetJokeIntentHandler,
    GetFartIntentHandler
  )
  .addRequestInterceptors(LocalizationInterceptor) // Include the localizationInterceptor
  .addErrorHandlers(ErrorHandler)
  .lambda();