module.exports = {
    
    addBreak : function (breakSeconds) {
        return `<break time="${breakSeconds}s"/>`;
    }
}