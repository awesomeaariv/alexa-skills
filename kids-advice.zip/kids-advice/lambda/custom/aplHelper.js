module.exports = {

// Checks if request is coming from a screen-based device or not.
supportsAPL : function (handlerInput) {
  const supportedInterfaces = handlerInput.requestEnvelope.context.System.device.supportedInterfaces;
  const aplInterface = supportedInterfaces['Alexa.Presentation.APL'];
  return aplInterface != null && aplInterface != undefined;
},

// Creates variables that we use in our APL layouts.
createDatasource : function (attributes) {
  return {
    "kidsAdviceData": {
      "properties": {
        "currentAdvice": "<speak>" + attributes.randomAdvice + "<speak>",
      }
    }
  };
}

};