module.exports = {
    translation : {
        SKILL_NAME : 'Kids Advice - UK!'
    }
};