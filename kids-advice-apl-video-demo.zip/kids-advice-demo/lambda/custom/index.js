const Alexa = require('ask-sdk-core');
const aplHelper = require('./aplHelper.js')

const i18n = require('i18next'); 
const sprintf = require('i18next-sprintf-postprocessor');

const languageStrings = {
  'en' : require('./i18n/en'),
};

function getAdvice(handlerInput) {
  const sessionAttributes = handlerInput.attributesManager.getSessionAttributes();
  const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

  const randomAdvice = requestAttributes.t('ADVICE');
  sessionAttributes.randomAdvice = randomAdvice;
  handlerInput.attributesManager.setSessionAttributes();
  
  const randomMusic = requestAttributes.t('MUSIC');
  const randomMorePrompt = requestAttributes.t('MORE_PROMPTS');
  const speechOutput = randomAdvice + randomMusic + randomMorePrompt;
  return speechOutput;
}

const GetAdviceIntentHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'LaunchRequest'
      || (request.type === 'IntentRequest'
        && request.intent.name === 'GetAdviceIntent');
  },
  handle(handlerInput) {
    const speechOutput = getAdvice(handlerInput);

    if(aplHelper.supportsAPL(handlerInput)) {
      return handlerInput.responseBuilder
        .speak(speechOutput)
        .addDirective({
          type: 'Alexa.Presentation.APL.RenderDocument',
          document: require('./apl/layouts/videoPlayer.json'),
          token: "VideoPlayerToken"
        })
        .addDirective({
          type: "Alexa.Presentation.APL.ExecuteCommands",
          token: "VideoPlayerToken",
          commands: [
            {
              type: "ControlMedia",
              componentId: "myVideoPlayer",
              command: "play"
            }
          ]
        })
        .getResponse();
    }
    else {
      return handlerInput.responseBuilder
        .speak("Sorry, this device doesn't show video.")
        .getResponse();
    }
  },
};

const YesIntentHandler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;

        return (request.type === 'IntentRequest'
            && request.intent.name === 'AMAZON.YesIntent');
      },
      handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

        const speechOutput = getAdvice(handlerInput);
      
        return handlerInput.responseBuilder
          .speak(speechOutput)
          .reprompt(requestAttributes.t('MORE_ADVICE_REPROMPT'))
          .getResponse();
      },
    };

const NoIntentHandler =  {
    canHandle(handlerInput) {
        const request = handlerInput.requestEnvelope.request;

        return (request.type === 'IntentRequest'
            && request.intent.name === 'AMAZON.NoIntent');
      },
      handle(handlerInput) {
        const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

        return handlerInput.responseBuilder
          .speak(requestAttributes.t('STOP_MESSAGE'))
          .getResponse();
      },
};

const HelpHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && request.intent.name === 'AMAZON.HelpIntent';
  },
  handle(handlerInput) {

    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

    return handlerInput.responseBuilder
      .speak(requestAttributes.t('HELP_MESSAGE'))
      .reprompt(requestAttributes.t('HELP_REPROMPT'))
      .getResponse();
  },
};

const FallbackHandler = {
    canHandle(handlerInput) {
      const request = handlerInput.requestEnvelope.request;

      return request.type === 'IntentRequest'
        && request.intent.name === 'AMAZON.FallbackIntent';
    },
    handle(handlerInput) {
      const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

      return handlerInput.responseBuilder
        .speak(requestAttributes.t('FALLBACK_MESSAGE'))
        .reprompt(requestAttributes.t('FALLBACK_REPROMPT'))
        .getResponse();
    },
  };

const ExitHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'IntentRequest'
      && (request.intent.name === 'AMAZON.CancelIntent'
        || request.intent.name === 'AMAZON.StopIntent');
  },
  handle(handlerInput) {
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

    return handlerInput.responseBuilder
      .speak(requestAttributes.t('STOP_MESSAGE'))
      .getResponse();
  },
};

const SessionEndedRequestHandler = {
  canHandle(handlerInput) {
    const request = handlerInput.requestEnvelope.request;
    return request.type === 'SessionEndedRequest';
  },
  handle(handlerInput) {
    console.log(`Session ended with reason: ${handlerInput.requestEnvelope.request.reason}`);

    return handlerInput.responseBuilder.getResponse();
  },
};

const ErrorHandler = {
  canHandle() {
    return true;
  },
  handle(handlerInput, error) {
    
    console.log(`Error handled: ${error.message}`);
    const requestAttributes = handlerInput.attributesManager.getRequestAttributes();

    return handlerInput.responseBuilder
      .speak(requestAttributes.t('DEFAULT_ERROR_MESSAGE'))
      .reprompt(requestAttributes.t('DEFAULT_ERROR_MESSAGE'))
      .getResponse();
  },
};

const LocalizationInterceptor = {
  process(handlerInput) {
      const localizationClient = i18n.use(sprintf).init({
          lng: handlerInput.requestEnvelope.request.locale,
          fallbackLng: 'en', // fallback to EN if locale doesn't exist
          resources: languageStrings
      });

      localizationClient.localize = function () {
          const args = arguments;
          let values = [];

          for (var i = 1; i < args.length; i++) {
              values.push(args[i]);
          }
          const value = i18n.t(args[0], {
              returnObjects: true,
              postProcess: 'sprintf',
              sprintf: values
          });

          if (Array.isArray(value)) {
              return value[Math.floor(Math.random() * value.length)];
          } else {
              return value;
          }
      };

      const attributes = handlerInput.attributesManager.getRequestAttributes();
      attributes.t = function (...args) { // pass on arguments to the localizationClient
          return localizationClient.localize(...args);
      };
  },
};

const skillBuilder = Alexa.SkillBuilders.custom();

exports.handler = skillBuilder
  .addRequestHandlers(
    GetAdviceIntentHandler,
    HelpHandler,
    ExitHandler,
    SessionEndedRequestHandler,
    YesIntentHandler,
    NoIntentHandler,
    FallbackHandler
  )
  // The reason we added a request interceptor is so that the SDK will run this every time a request comes in before we handle any request, ...
  // ... pre-filling our request attributes with the localization strings for the incoming locale.
  .addRequestInterceptors(LocalizationInterceptor) // Registers LocalizationInterceptor so we can use it
  .addErrorHandlers(ErrorHandler)
  .lambda();